# Calculadora de graus Celsius em Fahrenheit

A Pen created on CodePen.io. Original URL: [https://codepen.io/keziaferretti/pen/YzLpqoV](https://codepen.io/keziaferretti/pen/YzLpqoV).

